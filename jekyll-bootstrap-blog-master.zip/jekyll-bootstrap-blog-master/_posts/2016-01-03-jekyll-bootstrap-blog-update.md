---
layout: post
title: Jekyll 博客主题 jekyll-bootstrap-blog 更新，支持语法高亮
date: 2016-01-03 02:41
author: admin
comments: true
categories: [Blog,Jekyll]
tags: [Blog,Jekyll,jekyll-bootstrap-blog]
---

## New Features and Enhancements 

Todey, there are two features added in `jekyll-bootstrap-blog`:

* Syntax Highlighting (forked from <https://github.com/isagalaev/highlight.js>)
* Jekyll 3 Supported

<!-- more -->

The `jekyll-bootstrap-blog` is a theme for Jekyll to build a personal blog. See <https://github.com/waylau/jekyll-bootstrap-blog>

## Screenshots

![](http://99btgc01.info/uploads/2016/01/01.jpg)

![](http://99btgc01.info/uploads/2016/01/02%281%29.jpg)



## Demo

You can see the theme running on [my blog](http://www.waylau.com/).





