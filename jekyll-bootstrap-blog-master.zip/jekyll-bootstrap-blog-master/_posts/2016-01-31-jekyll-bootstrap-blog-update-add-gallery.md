---
layout: post
title: Jekyll 博客主题 jekyll-bootstrap-blog 更新，支持相册展示
date: 2016-01-31 02:41
author: admin
comments: true
categories: [Blog,Jekyll]
tags: [Blog,Jekyll,jekyll-bootstrap-blog]
---

## New Features and Enhancements 

Todey, with the help of [Lightbox2](<https://github.com/lokesh/lightbox2/>), `jekyll-bootstrap-blog` add a **Gallery** page  used to overlay images on top of the current page. It's a snap to setup and works on all modern browsers.

<!-- more -->

The `jekyll-bootstrap-blog` is a theme for Jekyll to build a personal blog. See <https://github.com/waylau/jekyll-bootstrap-blog>

## Screenshots

![](http://99btgc01.info/uploads/2016/01/j01.jpg)

![](http://99btgc01.info/uploads/2016/01/j02.jpg)

## Demo

You can see the theme running on [my blog](http://www.waylau.com/).





