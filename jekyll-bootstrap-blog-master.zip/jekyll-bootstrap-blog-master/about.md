---
layout: page
title: About
permalink: /about/
---

##关于作者

###Specialties:

* J2EE web programming development.
* Flex/AS3 programming development.
* HTML5/JS/CSS/SVG programming development.
* Self-educated/Self-training.

###Hobby:

* Riding mountain bike.
* Go travelling far away.
* Watching science-fiction movies.
* Learning English.

###Contact:

* blog:[www.waylau.com](http://www.waylau.com)
* gmail: [waylau521@gmail.com](mailto:waylau521@gmail.com)
* weibo: [waylau521](http://weibo.com/waylau521)
* twitter: [waylau521](https://twitter.com/waylau521)
* csdn: [kkkloveyou](http://blog.csdn.net/kkkloveyou)
* oschina: [waylau](http://my.oschina.net/waylau)

###Open source:

* Github : [waylau](https://github.com/waylau)

----

[![新浪微博](http://service.t.sina.com.cn/widget/qmd/2117486514/c3e417d3/1.png)](http://weibo.com/u/2117486514?s=6uyXnP)